#!/bin/sh
export CLASSPATH=$CLASSPATH:./config:./lib/*:./tlib/*
export CMD="org.apache.log4j.net.Log4jSocketServer"
export JAVA_OPTS="-server -Xmn128m -Xms256m -Xmx256m -Xss256K -XX:+DisableExplicitGC -XX:+UseConcMarkSweepGC -XX:+CMSParallelRemarkEnabled -XX:+UseCMSCompactAtFullCollection -XX:LargePageSizeInBytes=128m"
declare -a defMapValue=()
function loadProperties(){
    IFS='='
    while read k v
    do
        defMapValue[$k]=$v
    done < config/server.properties
    IFS=' '
}
loadProperties
for key in ${!defMapValue[@]}
do
  echo "启动服务端口:$key,配置文件:${defMapValue[$key]}"
  nohup java $JAVA_OPTS ${CMD} $key config/${defMapValue[$key]} . >/dev/null 2>&1 &
done