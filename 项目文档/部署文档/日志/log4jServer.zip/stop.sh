ps -ef |grep org.apache.log4j.net.Log4jSocketServer | grep -v grep | awk '{print $2}' | xargs kill -9
